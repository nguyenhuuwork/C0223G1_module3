package com.codegym.service;

import com.codegym.model.Clazz;

import java.util.List;

public interface IClazzService {
    List<Clazz> findAll();
}
